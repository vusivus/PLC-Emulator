package de.holger_oehm.pic.progmem.hexfile;

public enum RecordType {
    DATA, EOF, SEG_ADDR, SEG_START, LIN_ADDR, LIN_START,
}