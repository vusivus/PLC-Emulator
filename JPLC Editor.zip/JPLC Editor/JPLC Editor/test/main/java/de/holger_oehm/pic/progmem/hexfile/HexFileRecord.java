package de.holger_oehm.pic.progmem.hexfile;

public abstract class HexFileRecord {
    public abstract RecordType getType();
}