/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vts.jplceditor.compiler.pic18.mem;

/**
 *
 * @author Vusivus
 */
public class Pic18Config {

    public static int CONFIG1L = 0x03;
    public static int CONFIG1H = 0x0C;
    public static int CONFIG2L = 0x36;
    public static int CONFIG2H = 0x13;
    public static int CONFIG3L = 0;
    public static int CONFIG3H = 0x85;
    public static int CONFIG4L = 0xA5;
    public static int CONFIG4H = 0;
    public static int CONFIG5L = 0x3F;
    public static int CONFIG5H = 0xC0;
    public static int CONFIG6L = 0;
    public static int CONFIG6H = 0;
    public static int CONFIG7L = 0;
    public static int CONFIG7H = 0;
    public static int DEVID2 = 0X12;
    public static int DEVID1 = 0X40;
}
