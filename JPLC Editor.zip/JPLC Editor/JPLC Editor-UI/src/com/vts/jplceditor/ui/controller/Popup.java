/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vts.jplceditor.ui.controller;

/**
 *
 * @author Vusumuzi_Tshabangu
 */
public enum Popup {

    /**
     *
     */
    TagWindow,

    /**
     *
     */
    RungWindow,

    /**
     *
     */
    ProgramWindow,

    /**
     *
     */
    ProjectWindow
}
